//
//  EMCommonDefs.h
//  HyphenateSDK
//
//  Created by XieYajie on 3/25/16.
//  Copyright © 2016 easemob.com. All rights reserved.
//

#ifndef EMCommonDefs_h
#define EMCommonDefs_h

#define EM_DEPRECATED_IOS(_hyphenateIntro, _hyphenateDep, ...) __attribute__((deprecated("")))

#endif /* EMCommonDefs_h */
